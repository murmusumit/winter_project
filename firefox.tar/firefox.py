#!/usr/bin/python

import commands

commands.getoutput('ssh -X 127.0.0.1 firefox')
